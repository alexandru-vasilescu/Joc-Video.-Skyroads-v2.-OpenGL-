#pragma once
#include <Component/SimpleScene.h>
#include <string>
#include <Core/Engine.h>
#include <vector>
#include <iostream>
#include "Camera.h"
#include "Transform3D.h"
#include "Structures.h"
#include "Lane.h"
#include "Transform2D.h"
#include "math.h"
#include "Building.h"
class Tema2 : public SimpleScene
{
public:
	Tema2();
	~Tema2();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, int colide,int is_person, int apply_light, Texture2D* texture = NULL);
	void Render2DMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, Texture2D* texture = NULL);
	void InitTextures();
	void car();
	void cilindru();
	void con();
	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	bool PlatformMove(float deltaTimeSeconds, platforma* p, bool collision);
	bool LaneMove(Lane* l, float deltaTimeSeconds);
	bool colide(platforma* p);
	void restart();
	void drawBox(platforma* p);
	void drawWall(platforma* p);
	void drawJaloane(platforma* p);
	void drawGarbageCans(platforma* p);
	bool collision_obstacol(obstacol o, int type);
	bool collision_coin(coin c);
	bool collision_fuel(fuel_tank f);
	void drawCoins(float deltaTimeSeconds, platforma* p);
	void drawOneCoin(float deltaTimeSeconds, coin* c);
	void drawFuel(float deltaTimeSeconds, fuel_tank* ft);
	void cub();
	void BuildingMove(float deltaTimeSeconds, Building *b);
	bool CladireMove(float deltaTimeSeconds, cladire* c);
	
protected:
	Camera* camera;
	glm::mat4 projectionMatrix;
	bool renderCameraTarget;
	float FoV;
	//platforme
	std::vector<Lane*> lanes;
	std::vector<glm::vec3> colors;
	float speed = 2;
	float max_speed = 8;
	float min_speed = 2;
	//personaj
	personaj pers;
	bool start = false;
	float gravity = -2;
	float min_gravity = -2;
	float max_gravity = 1;
	bool fall = false;
	int super_speed = 0;
	float buff_duration = 5;
	int death = 0;
	float time_of_death = 0;
	
	float combustibil = 100;

	bool modified = false;
	int Score = 0;
	bool printed = false;

	glm::vec3 lightPosition;
	unsigned int materialShininess;
	float materialKd;
	float materialKs;
	
	//spot
	glm::vec3 lightDirection;
	int spot;
	float cut_off_angle = RADIANS(45);
	float x_angle;
	float y_angle;
	float rad;
	std::unordered_map<std::string, Texture2D*> mapTextures;
	std::vector<Texture2D*> numbers;
	//
	float wheel_rotation;
	masina masina;
	float sun_rotation = 0;
	std::vector<Building*> buildings;
	std::vector<Texture2D*> floors;
	std::vector<Texture2D*> base;
};
