#include "Tema2.h"

using namespace std;
using namespace Transform3D;

Tema2::Tema2()
{
}

Tema2::~Tema2()
{
}
void Tema2::restart()
{
	while (!lanes.empty())
		lanes.erase(lanes.begin());
	renderCameraTarget = false;

	while (!buildings.empty())
		buildings.erase(buildings.begin());
	camera = new Camera();
	camera->Set(glm::vec3(0, 2, 3), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	{
		Lane* l;
		l = new Lane(camera->position.z, 0);
		lanes.push_back(l);
		l = new Lane(camera->position.z, 5);
		lanes.push_back(l);
		l = new Lane(camera->position.z, -5);
		lanes.push_back(l);
	}
	{
		Building* b;
		b = new Building(camera->position.z, 6.5);
		buildings.push_back(b);
		b = new Building(camera->position.z, -8.5);
		buildings.push_back(b);
	}
	{
		pers.tx = camera->position.x;
		pers.ty = 0.1 + pers.sy;
		pers.tz = camera->position.z;
	}
	{
		lightPosition = glm::vec3(0, 3, -10);
		lightDirection = glm::vec3(0, -1, 0);
		materialShininess = 30;
		materialKd = 0.5;
		materialKs = 0.25;
		spot = 1;
	}
	speed = 2;
	start = false;
	gravity = -2;
	fall = false;
	super_speed = 0;
	buff_duration = 5;
	death = 0;
	time_of_death = 0;
	combustibil = 100;
	modified = false;
	Score = 0;
	printed = false;
	masina.tx = 0;
	masina.ty = 0.2;
	masina.tz = 0;
}


void Tema2::InitTextures()
{
	const string textureLoc = "Source/Laboratoare/Tema2/Textures/";
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "Lane.png").c_str(), GL_REPEAT);
		mapTextures["Lane"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "Sky.jpg").c_str(), GL_REPEAT);
		mapTextures["Sky"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "car_up.png").c_str(), GL_REPEAT);
		mapTextures["car_up"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "car_bottom.png").c_str(), GL_REPEAT);
		mapTextures["car_bottom"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "wheel.png").c_str(), GL_REPEAT);
		mapTextures["wheel"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "explosion.jpg").c_str(), GL_REPEAT);
		mapTextures["explosion"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "jalon.png").c_str(), GL_REPEAT);
		mapTextures["jalon"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "crate.png").c_str(), GL_REPEAT);
		mapTextures["crate"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "wall.jpg").c_str(), GL_REPEAT);
		mapTextures["wall"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "house1.jpg").c_str(), GL_REPEAT);
		base.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "building1.jpg").c_str(), GL_REPEAT);
		floors.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "house2.jpg").c_str(), GL_REPEAT);
		base.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "building2.jpg").c_str(), GL_REPEAT);
		floors.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "house3.jpg").c_str(), GL_REPEAT);
		base.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "building3.jpg").c_str(), GL_REPEAT);
		floors.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "metal.jpg").c_str(), GL_REPEAT);
		mapTextures["metal"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "coin.jpg").c_str(), GL_REPEAT);
		mapTextures["coin"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "fuel.jpg").c_str(), GL_REPEAT);
		mapTextures["fuel"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "white.jpg").c_str(), GL_REPEAT);
		mapTextures["white"] = texture;
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "zero.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "one.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "two.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "three.png").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "four.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "five.png").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "six.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "seven.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "eight.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "nine.jpg").c_str(), GL_REPEAT);
		numbers.push_back(texture);
	}
	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "game_over.jpg").c_str(), GL_REPEAT);
		mapTextures["game_over"] = texture;
	}
}
void Tema2::car()
{
	vector<VertexFormat> vertices{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(0,1)),
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(0, 0, 1.25), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(1,1)),
			VertexFormat(glm::vec3(1,0,1.25), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(1,0)),
			VertexFormat(glm::vec3(0.15,0.25,0.20),glm::vec3(0,0,0),glm::normalize(glm::vec3(0.3,0.5,0.3)), glm::vec2(0.3,0.8)),
			VertexFormat(glm::vec3(0.15,0.25,0.80),glm::vec3(0,0,0),glm::normalize(glm::vec3(0.3,0.5,0.7)),glm::vec2(0.6,0.8)),
			VertexFormat(glm::vec3(0.85,0.25,0.20),glm::vec3(0,0,0),glm::normalize(glm::vec3(0.7,0.5,0.3)),glm::vec2(0.3,0.2)),
			VertexFormat(glm::vec3(0.85,0.25,0.80),glm::vec3(0,0,0),glm::normalize(glm::vec3(0.7,0.5,0.7)),glm::vec2(0.6,0.2)),
	};
	vector<unsigned short> indices{
		0,1,2,
		1,3,2,
		0,4,6,
		0,6,1,
		0,2,5,
		0,5,4,
		2,3,7,
		2,7,5,
		1,6,7,
		1,7,3,
		4,5,7,
		4,7,6,
	};
	Mesh* mesh = new Mesh("car");
	mesh->InitFromData(vertices, indices);
	meshes[mesh->GetMeshID()] = mesh;
	vector<VertexFormat> vertices2{
			//dreptunghiul de jos
			VertexFormat(glm::vec3(0,0,-0.5),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(0,0)),
			VertexFormat(glm::vec3(1, 0, -0.5), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(0, 0, 1.5), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1,0,1.5), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(0,0)),
			//drepturnghiul de sus
			VertexFormat(glm::vec3(0,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(0.1,0.75)),
			VertexFormat(glm::vec3(0,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(0.9,0.75)),
			VertexFormat(glm::vec3(1,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,0)),glm::vec2(0.1,0.25)),
			VertexFormat(glm::vec3(1,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,1)),glm::vec2(0.9,0.25)),
			//drepturnghiul din fata
			VertexFormat(glm::vec3(1, 0, -0.5), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0.1,0)),
			VertexFormat(glm::vec3(1,0,1.5), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(0.9,0)),
			VertexFormat(glm::vec3(1,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,0)),glm::vec2(0.1,0.2)),
			VertexFormat(glm::vec3(1,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,1)),glm::vec2(0.9,0.2)),
			//dreptunghi spate
			VertexFormat(glm::vec3(0,0,-0.5),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(0.1,1)),
			VertexFormat(glm::vec3(0, 0, 1.5), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(0.9,1)),
			VertexFormat(glm::vec3(0,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(0.1,0.8)),
			VertexFormat(glm::vec3(0,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(0.9,0.8)),
			//dreptunghi stanga
			VertexFormat(glm::vec3(0,0,-0.5),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(0,0.75)),
			VertexFormat(glm::vec3(1, 0, -0.5), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0,0.25)),
			VertexFormat(glm::vec3(0,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(0.1,0.75)),
			VertexFormat(glm::vec3(1,0.5,-0.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,0)),glm::vec2(0.1,0.25)),
			//dreptunghi dreapta
			VertexFormat(glm::vec3(0, 0, 1.5), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(1,0.75)),
			VertexFormat(glm::vec3(1,0,1.5), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(1,0.25)),
			VertexFormat(glm::vec3(0,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(0.9,0.75)),
			VertexFormat(glm::vec3(1,0.5,1.5),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,1)),glm::vec2(0.9,0.25)),
	};
	vector<unsigned short> indices2{
		0,1,2,
		1,3,2,
		4,5,7,
		4,7,6,
		8,9,11,
		11,10,8,
		12,14,15,
		12,15,13,
		20,22,23,
		20,23,21,
		16,17,19,
		16,19,18,
	};
	mesh = new Mesh("car_bottom");
	mesh->InitFromData(vertices2, indices2);
	meshes[mesh->GetMeshID()] = mesh;
}
void Tema2::cilindru()
{
	float z = 1;
	float y = 1;
	float x = 1;
	float dist_intre_puncte = 0.01;
	vector<VertexFormat> vertices;
	vector<unsigned short> indices;
	vertices.push_back(VertexFormat(glm::vec3(0), glm::vec3(0), glm::vec3(0), glm::vec2(0.5,0.5)));
	vertices.push_back(VertexFormat(glm::vec3(x,0,0), glm::vec3(0), glm::vec3(x,0,0), glm::vec2(0.5,0.5)));
	while (z > -1)
	{
		y = sqrt(1 - z * z);
		glm::vec3 pos = glm::vec3(0, y, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + y/2, 0.5 + z/2)));
		pos = glm::vec3(x, y, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + y/2, 0.5 + z/2)));
		z -= dist_intre_puncte;
	}
	while (z < 1)
	{
		y = -sqrt(1 - z * z);
		glm::vec3 pos = glm::vec3(0, y, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + y / 2, 0.5 + z / 2)));
		pos = glm::vec3(x, y, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + y / 2, 0.5 + z / 2)));
		z += dist_intre_puncte;
	}
	for(int i = 2; i < vertices.size() - 2; i++)
	{
		indices.push_back(i % 2);
		indices.push_back(i);
		indices.push_back(i + 2);
	}
	indices.push_back(0);
	indices.push_back(vertices.size()-2);
	indices.push_back(2);
	indices.push_back(1);
	indices.push_back(vertices.size() - 1);
	indices.push_back(3);
	for(int i = 2; i < vertices.size() - 2; i++)
	{
		indices.push_back(i);
		indices.push_back(i + 1);
		indices.push_back(i + 2);
	}
	
	indices.push_back(vertices.size() - 2);
	indices.push_back(vertices.size() - 1);
	indices.push_back(2);
	indices.push_back(vertices.size() - 1);
	indices.push_back(2);
	indices.push_back(3);
	Mesh* mesh = new Mesh("cilindru");
	mesh->InitFromData(vertices, indices);
	meshes[mesh->GetMeshID()] = mesh;
}
void Tema2::con()
{
	float z = 1;
	float y = 1;
	float x = 1;
	float dist_intre_puncte = 0.01;
	vector<VertexFormat> vertices;
	vector<unsigned short> indices;
	vertices.push_back(VertexFormat(glm::vec3(0), glm::vec3(0), glm::vec3(0), glm::vec2(0.5, 0.5)));
	vertices.push_back(VertexFormat(glm::vec3(0, y, 0), glm::vec3(0), glm::vec3(0, y, 0), glm::vec2(0.5, 0.5)));
	while (z > -1)
	{
		x = sqrt(1 - z * z);
		glm::vec3 pos = glm::vec3(x, 0, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + x / 2, 0.5 + z / 2)));
		z -= dist_intre_puncte;
	}
	while (z < 1)
	{
		x = -sqrt(1 - z * z);
		glm::vec3 pos = glm::vec3(x, 0, z);
		vertices.push_back(VertexFormat(pos, glm::vec3(0), glm::normalize(pos), glm::vec2(0.5 + x / 2, 0.5 + z / 2)));
		z += dist_intre_puncte;
	}
	for (int i = 2; i < vertices.size() - 1; i++)
	{
		indices.push_back(0);
		indices.push_back(i);
		indices.push_back(i + 1);
		indices.push_back(1);
		indices.push_back(i);
		indices.push_back(i + 1);
	}
	indices.push_back(0);
	indices.push_back(vertices.size() - 1);
	indices.push_back(2);
	indices.push_back(1);
	indices.push_back(vertices.size() - 1);
	indices.push_back(2);
	Mesh* mesh = new Mesh("con");
	mesh->InitFromData(vertices, indices);
	meshes[mesh->GetMeshID()] = mesh;
}
void Tema2::cub()
{
	vector<VertexFormat> vertices
	{
		//dreptunghiul de jos
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(0,0)),
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(0, 0, 1), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1,0,1), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(0,0)),
			//drepturnghiul de sus
			VertexFormat(glm::vec3(0,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(0,0)),
			VertexFormat(glm::vec3(0,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,0)),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,1)),glm::vec2(0,0)),
			//drepturnghiul din fata
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(1,1)),
			VertexFormat(glm::vec3(1,0,1), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(0,1)),
			VertexFormat(glm::vec3(1,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,1,0)),glm::vec2(1,0)),
			VertexFormat(glm::vec3(1,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,1,1)),glm::vec2(0,0)),
			//dreptunghi spate
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(1,1)),
			VertexFormat(glm::vec3(0, 0, 1), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(0,1)),
			VertexFormat(glm::vec3(0,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(1,0)),
			VertexFormat(glm::vec3(0,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(0,0)),
			//dreptunghi stanga
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0), glm::normalize(glm::vec3(0,0,0)), glm::vec2(1,1)),
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0),glm::normalize(glm::vec3(1, 0, 0)),glm::vec2(0,1)),
			VertexFormat(glm::vec3(0,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,0)), glm::vec2(1,0)),
			VertexFormat(glm::vec3(1,1,0),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,0)),glm::vec2(0,0)),
			//dreptunghi dreapta
			VertexFormat(glm::vec3(0, 0, 1), glm::vec3(1, 1, 0),glm::normalize(glm::vec3(0, 0, 1)),glm::vec2(1,1)),
			VertexFormat(glm::vec3(1,0,1), glm::vec3(1,0,0),glm::normalize(glm::vec3(1,0,1)),glm::vec2(0,1)),
			VertexFormat(glm::vec3(0,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(0,0.5,1)),glm::vec2(1,0)),
			VertexFormat(glm::vec3(1,1,1),glm::vec3(0,0,0),glm::normalize(glm::vec3(1,0.5,1)),glm::vec2(0,0)),
	};

	vector<unsigned short> indices =
	{
		0,1,2,
		1,3,2,
		4,5,7,
		4,7,6,
		8,9,11,
		11,10,8,
		12,14,15,
		12,15,13,
		20,22,23,
		20,23,21,
		16,17,19,
		16,19,18,
	};
	Mesh* mesh = new Mesh("cub");
	mesh->InitFromData(vertices, indices);
	meshes[mesh->GetMeshID()] = mesh;
}
void Tema2::Init()
{
	restart();
	InitTextures();
	FoV = RADIANS(60);
	
	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Shader* shader = new Shader("Tema2");
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema2/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}
	{
		Shader* shader = new Shader("2D");
		shader->AddShader("Source/Laboratoare/Tema2/Shaders2D/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Tema2/Shaders2D/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}
	//combustibil
	{
		vector<VertexFormat> vertices{
			VertexFormat(glm::vec3(0,0,0),glm::vec3(1,1,0), glm::vec3(0,0,0),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1, 0, 0),glm::vec3(1,0,0),glm::vec2(1,0)),
			VertexFormat(glm::vec3(0, 1, 0), glm::vec3(1, 1, 0),glm::vec3(0,1,0),glm::vec2(0,1)),
			VertexFormat(glm::vec3(1,1,0), glm::vec3(1,0,0),glm::vec3(1,1,0),glm::vec2(1,1))
		};
		vector<unsigned short> indices{
			0,1,2,
			1,3,2
		};
		Mesh* mesh = new Mesh("Combustibil");
		mesh->InitFromData(vertices, indices);
		meshes[mesh->GetMeshID()] = mesh;
	}
	//combustibil background
	{
		vector<VertexFormat> vertices{
			VertexFormat(glm::vec3(-0.1,-0.1,0),glm::vec3(1,1,1), glm::vec3(0,0,0),glm::vec2(0,0)),
			VertexFormat(glm::vec3(1.1, -0.1, 0), glm::vec3(1,1,1),glm::vec3(1,0,0),glm::vec2(1,0)),
			VertexFormat(glm::vec3(-0.1, 1.1, 0), glm::vec3(1,1,1),glm::vec3(0,1,0),glm::vec2(0,1)),
			VertexFormat(glm::vec3(1.1,1.1,0), glm::vec3(1,1,1),glm::vec3(1,1,0),glm::vec2(1,1))
		};
		vector<unsigned short> indices{
			0,1,2,
			1,3,2
		};
		Mesh* mesh = new Mesh("Combustibil2");
		mesh->InitFromData(vertices, indices);
		meshes[mesh->GetMeshID()] = mesh;
		
	}
	car();
	cilindru();
	con();
	cub();
	projectionMatrix = glm::perspective(FoV, window->props.aspectRatio, 0.01f, 200.0f);
}
void Tema2::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}
bool Tema2::collision_obstacol(obstacol o, int type)
{
	if(pers.tz + pers.sz>= o.tz - o.sz/2 && pers.tz - pers.sz<= o.tz + o.sz/2)
	{
		if (pers.tx - pers.sx / 2 <= o.tx + o.sx / 2 && pers.tx + pers.sx / 2 >= o.tx - o.sx / 2)
			if(pers.ty - pers.sy/2 <= 0 + o.sy)
			{
				return true;
			}
	}
	return false;
}
bool Tema2::collision_fuel(fuel_tank f)
{
	if (pers.tz + pers.sz >= f.tz - f.sz / 2 && pers.tz - pers.sz <= f.tz + f.sz / 2)
	{
		if (pers.tx - pers.sx / 2 <= f.tx + f.sx / 2 && pers.tx + pers.sx / 2 >= f.tx - f.sx / 2)
			if (pers.ty - pers.sy / 2 <= 0 + f.sy)
			{
				return true;
			}
	}
	return false;
}
void Tema2::drawBox(platforma *p)
{
	if (collision_obstacol(p->o, p->obstacle_type))
		death = 1;
	glm::mat4 modelMatrix = glm::mat4(1);
	modelMatrix *= Translate(p->tx - p->sx /4, p->sy / 2 + 0.5, p->tz + p->position_platform);
	modelMatrix *= Scale(1, 1, 1);
	RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["crate"]);
	modelMatrix = glm::mat4(1);
	modelMatrix *= Translate(p->tx + p->sx / 4, p->sy / 2 + 0.5, p->tz + p->position_platform);
	modelMatrix *= Scale(1, 1, 1);
	RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["crate"]);
}
void Tema2::drawWall(platforma* p)
{
	if(collision_obstacol(p->o, p->obstacle_type))
		death = 1;
	glm::mat4 modelMatrix = glm::mat4(1);
	modelMatrix *= Translate(p->tx, p->sy / 2 + 0.5 * 3, p->tz + p->position_platform);
	modelMatrix *= Scale(p->sx, 3, 0.3);
	RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["wall"]);

}
void Tema2::drawJaloane(platforma* p)
{
	if(collision_obstacol(p->o, p->obstacle_type))
	{
		if(modified == false)
		{
			combustibil -= 10;
			modified = true;
		}
		p->o.draw = false;
	}
	if(p->o.draw) 
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.5, 0.25);
		RenderSimpleMesh(meshes["con"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["jalon"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx + p->sx / 6, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.5, 0.25);
		RenderSimpleMesh(meshes["con"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["jalon"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx - p->sx / 6, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.5, 0.25);
		RenderSimpleMesh(meshes["con"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["jalon"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx + p->sx / 3, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.5, 0.25);
		RenderSimpleMesh(meshes["con"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["jalon"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx - p->sx / 3, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.5, 0.25);
		RenderSimpleMesh(meshes["con"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["jalon"]);
	}
}
void Tema2::drawGarbageCans(platforma* p)
{
	if(collision_obstacol(p->o, p->obstacle_type))
	{
		if (modified == false)
		{
			if (Score > 10)
				Score -= 10;
			else Score = 0;
			combustibil -= 20;
			modified = true;
		}
		p->o.draw = false;
	}
	if (p->o.draw) {
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx - p->sx / 10, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.2, 0.75, 0.2);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx - p->sx / 10, p->sy / 2 + 0.70, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.1, 0.25);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx + p->sx / 10, p->sy / 2, p->tz + p->position_platform);
		modelMatrix *= Scale(0.2, 0.75, 0.2);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx + p->sx / 10, p->sy / 2 + 0.70, p->tz + p->position_platform);
		modelMatrix *= Scale(0.25, 0.1, 0.25);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx, p->sy / 2, p->tz + p->position_platform - 0.5);
		modelMatrix *= Scale(0.2, 0.75, 0.2);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(p->tx, p->sy / 2 + 0.70, p->tz + p->position_platform - 0.5);
		modelMatrix *= Scale(0.25, 0.1, 0.25);
		modelMatrix *= RotateOZ(RADIANS(90));
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
	}
}
bool Tema2::collision_coin(coin c)
{
	if (pers.tz + pers.sz >= c.tz - c.sz / 2 && pers.tz - pers.sz <= c.tz + c.sz / 2)
	{
		if (pers.tx - pers.sx <= c.tx + c.sx / 2 && pers.tx + pers.sx >= c.tx - c.sx / 2)
		{
				return true;
		}
	}
	return false;
}
void Tema2::drawOneCoin(float deltaTimeSeconds, coin *c)
{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (c->up > 0.2)
			c->sign = -1;
		if (c->up < -0.2)
			c->sign = 1;
		c->up += deltaTimeSeconds * c->sign * 0.1;
		modelMatrix *= Translate(c->tx, c->ty + c->up, c->tz);
		modelMatrix *= RotateOY(RADIANS(90));
		c->rotation += deltaTimeSeconds;
		modelMatrix *= RotateOY(c->rotation);
		modelMatrix *= Scale(c->sx * 0.2, c->sy, c->sz);
		RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 0, 0, mapTextures["coin"]);
}
void Tema2::drawCoins(float deltaTimeSeconds, platforma *p)
{
	for (int i = 0; i < p->coins.size(); i++) {
		if(collision_coin(p->coins[i]))
		{
			Score++;
			p->coins.erase(p->coins.begin() + i);
			continue;
		}
		drawOneCoin(deltaTimeSeconds, &p->coins[i]);
	}
}
void Tema2::drawFuel(float deltaTimeSeconds, fuel_tank* ft)
{
	if(collision_fuel(*ft))
	{
		if (modified == false)
		{
			if (combustibil < 70)
				combustibil += 30;
			else combustibil = 100;
			modified = true;
		}
		ft->draw = false;
	}
	if (ft->draw) {
		glm::mat4 modelMatrix = glm::mat4(1);
		if (ft->up > 0.2)
			ft->sign = -1;
		if (ft->up < -0.2)
			ft->sign = 1;
		ft->up += deltaTimeSeconds * ft->sign * 0.1;
		modelMatrix *= Translate(ft->tx, ft->ty + ft->up, ft->tz);
		modelMatrix *= RotateOY(RADIANS(90));
		ft->rotation += deltaTimeSeconds;
		modelMatrix *= RotateOY(ft->rotation);
		modelMatrix *= Scale(ft->sx * 0.5, ft->sy, ft->sz);
		RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, 0, 0, 0, mapTextures["fuel"]);
	}
}
bool Tema2::PlatformMove(float deltaTimeSeconds, platforma* p, bool collision)
{
	if (p->tz < camera->position.z + p->sz/2)
	{
		if (start) {
			p->tz += deltaTimeSeconds * speed;
			p->o.tz += deltaTimeSeconds * speed;
			for (int i = 0; i < p->coins.size(); i++)
				p->coins[i].tz += deltaTimeSeconds * speed;
			p->fuel_tank.tz += deltaTimeSeconds * speed;
 		}
		if(!p->empty)
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix *= Translate(p->tx, 0, p->tz);
			modelMatrix *= Scale(p->sx, p->sy, p->sz);
			RenderSimpleMesh(meshes["box"], shaders["Tema2"], modelMatrix, (int)collision,0, 1, mapTextures["Lane"]);
			if(p->has_obstacle)
			{
				if (p->obstacle_type == 0)
					drawBox(p);
				if (p->obstacle_type == 1)
					drawWall(p);
				if (p->obstacle_type == 2)
					drawJaloane(p);
				if (p->obstacle_type == 3) {
					drawGarbageCans(p);
				}
			}
			drawCoins(deltaTimeSeconds, p);
			if(p->has_fuel_canister)
			{
				drawFuel(deltaTimeSeconds, &p->fuel_tank);
			}
		}
		return false;
	}
	return true;
}
bool Tema2::LaneMove(Lane* lane, float deltaTimeSeconds)
{
	bool any_platform = false;
	for (int i = 0; i < lane->p_center.size(); i++)
	{
		bool collision = false;
		if(!lane->p_center[i].empty)
		{
			collision = colide(&lane->p_center[i]);
			any_platform = any_platform | collision;
		}
		if (PlatformMove(deltaTimeSeconds, &lane->p_center[i], collision))
		{
			lane->p_center.erase(lane->p_center.begin());
		}
	}
	return any_platform;
}
bool Tema2::colide(platforma* p)
{
	if(pers.ty - pers.sy > -0.1 && pers.ty - pers.sy < 0.1)
	{
		if (pers.tz > p->tz - p->sz/2 && pers.tz < p->tz + p->sz/2 && pers.tx > p->tx - p->sx/2 && pers.tx < p->tx + p->sx/2) {
			return true;
		}
	}
	return false;
}
bool Tema2::CladireMove(float deltaTimeSeconds, cladire* c)
{
	if (c->tz < camera->position.z)
	{
		if (start) {
			c->tz += deltaTimeSeconds * speed;
		}
		for (int i = 0; i < c->floors; i++) {
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix *= Translate(c->tx, c->ty + c->sy*i, c->tz);
			modelMatrix *= Scale(c->sx, c->sy, c->sz);
			if (i == 0) {
				RenderSimpleMesh(meshes["cub"], shaders["Tema2"], modelMatrix, 0, 0, 1, base[c->texture_type[i]]);
			}else
			{
				RenderSimpleMesh(meshes["cub"], shaders["Tema2"], modelMatrix, 0, 0, 1, floors[c->texture_type[i]]);
			}
		}
		return false;
	}
	return true;
}

void Tema2::BuildingMove(float deltaTimeSeconds, Building* b)
{
	for(int i = 0; i < b->cladiri.size(); i++)
	{
		if(CladireMove(deltaTimeSeconds, &b->cladiri[i]))
		{
			b->cladiri.erase(b->cladiri.begin());
		}
	}
}

void Tema2::Update(float deltaTimeSeconds)
{
	if (start) {
		combustibil -= deltaTimeSeconds;
	}
	if (combustibil < 0)
		death = 1;
	if(pers.ty < -3)
	{
		death = 1;
	}
	if(death && time_of_death < 1)
	{
		start = 0;
		time_of_death += deltaTimeSeconds;
	}
	if (time_of_death > 1 && !printed) {
		cout << "SCORE: " << Score << endl;
		cout << "PRESS R TO RESTART!" << endl;
		printed = true;
	}
	
	if(super_speed == 1 && start)
	{
		speed = 10;
		buff_duration -= deltaTimeSeconds;
	}
	if(buff_duration < 0 && start)
	{
		buff_duration = 10;
		speed = min_speed;
		super_speed = 0;
	}
	bool any_platform = false;
	for (Lane* l : lanes) {
		l->PlatformGenerator();
		any_platform = any_platform | LaneMove(l, deltaTimeSeconds);
	}
	for (Building* b : buildings)
	{
		b->PlatformGenerator();
		BuildingMove(deltaTimeSeconds, b);
	}
	fall = any_platform;
	if (gravity > min_gravity)
		gravity -= deltaTimeSeconds;
	if (start && !fall)
		pers.ty += gravity * deltaTimeSeconds;
	if (pers.jump) {
		pers.ty += gravity * deltaTimeSeconds;
		if (gravity < 0) {
			pers.jump = false;	
			modified = false;
		}
	}
	if(time_of_death > 1)
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(-0.25, 0.25, 0);
		modelMatrix *= Transform3D::Scale(0.5, -0.5, 0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, mapTextures["game_over"]);
	}
	if (renderCameraTarget)
	{
		camera->position = glm::vec3(pers.tx, pers.ty + 1, pers.tz + 3);
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(pers.tx, pers.ty, pers.tz);
		modelMatrix *= Scale(pers.sx, pers.sy, pers.sz);
		if (death) {
			if (time_of_death < 1)
				RenderSimpleMesh(meshes["sphere"], shaders["Tema2"], modelMatrix, 0, 1, 0, mapTextures["explosion"]);
		}else
		{
			{
				masina.tx = pers.tx - masina.sx / 2;
				masina.ty = pers.ty;
				masina.tz = pers.tz;
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix *= Transform3D::Translate(masina.tx, masina.ty + masina.sy * 0.5, masina.tz + 0.2 * masina.sz);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
				RenderSimpleMesh(meshes["car"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["car_up"]);
				modelMatrix = glm::mat4(1);
				modelMatrix *= Transform3D::Translate(masina.tx, masina.ty, masina.tz);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
				RenderSimpleMesh(meshes["car_bottom"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["car_bottom"]);
				wheel_rotation -= 2 * deltaTimeSeconds;
				modelMatrix = glm::mat4(1);
				modelMatrix *= Transform3D::Translate(masina.tx + 0.8 * masina.sx, masina.ty + 0.15 * masina.sy, masina.tz);
				modelMatrix *= Transform3D::Scale(0.25, 0.25, 0.25);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
				modelMatrix *= Transform3D::RotateOX(wheel_rotation);
				
				RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["wheel"]);
				modelMatrix = glm::mat4(1);
				modelMatrix *= Transform3D::Translate(masina.tx - 0.05 * masina.sx, masina.ty + 0.15 * masina.sy, masina.tz);
				modelMatrix *= Transform3D::Scale(0.25, 0.25, 0.25);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
				modelMatrix *= Transform3D::RotateOX(wheel_rotation);
				
				RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["wheel"]);
				modelMatrix = glm::mat4(1);
				modelMatrix *= Transform3D::Translate(masina.tx + 0.8 * masina.sx, masina.ty + 0.15 * masina.sy, masina.tz + 1.15 * masina.sz);
				modelMatrix *= Transform3D::Scale(0.25, 0.25, 0.25);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
				modelMatrix *= Transform3D::RotateOX(wheel_rotation);
				
				RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["wheel"]);
				modelMatrix = glm::mat4(1);
				
				modelMatrix *= Transform3D::Translate(masina.tx - 0.05 * masina.sx, masina.ty + 0.15 * masina.sy, masina.tz + 1.15 * masina.sz);
				modelMatrix *= Transform3D::Scale(0.25, 0.25, 0.25);
				modelMatrix *= Transform3D::Scale(masina.sx, masina.sy, masina.sz);
	
				modelMatrix *= Transform3D::RotateOX(wheel_rotation);
				RenderSimpleMesh(meshes["cilindru"], shaders["Tema2"], modelMatrix, 0, 1, 1, mapTextures["wheel"]);
				
			}
		}
	}
	else
	{
		camera->position = glm::vec3(pers.tx, pers.ty, pers.tz);
	}
	//cerul
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Scale(-100,-100,-100);
		RenderSimpleMesh(meshes["sphere"], shaders["Tema2"], modelMatrix, 0, 0, 0, mapTextures["Sky"]);
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		sun_rotation -= deltaTimeSeconds/10;
		modelMatrix *= RotateOX(sun_rotation);
		modelMatrix *= Translate(0, 50, 0);
		modelMatrix *= Scale(4, 4, 4);
		RenderSimpleMesh(meshes["sphere"], shaders["Tema2"], modelMatrix, 0, 0, 0, mapTextures["explosion"]);
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(0.4, 0.85,0);
		modelMatrix *= Transform3D::Scale(MAX(combustibil/200 , 0), 0.1,0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, mapTextures["fuel"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(0.4, 0.85,0);
		modelMatrix *= Transform3D::Scale(0.5, 0.1,0);
		Render2DMesh(meshes["Combustibil2"], shaders["2D"], modelMatrix, mapTextures["white"]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(-0.9, 0.9, 0);
		modelMatrix *= Transform3D::Scale(0.1, -0.1, 0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, numbers[(Score/1000)%10]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(-0.8, 0.9, 0);
		modelMatrix *= Transform3D::Scale(0.1, -0.1, 0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, numbers[(Score/100)%10]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(-0.7, 0.9, 0);
		modelMatrix *= Transform3D::Scale(0.1, -0.1, 0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, numbers[(Score/10)%10]);
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform3D::Translate(-0.6, 0.9, 0);
		modelMatrix *= Transform3D::Scale(0.1, -0.1, 0);
		Render2DMesh(meshes["Combustibil"], shaders["2D"], modelMatrix, numbers[Score%10]);
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix *= Translate(-100, -0.5, -100);
		modelMatrix *= Scale(200, 0.5, 200);
		RenderSimpleMesh(meshes["cub"], shaders["Tema2"], modelMatrix, 0, 0, 1, mapTextures["metal"]);
	}
}

void Tema2::FrameEnd()
{
	 // DrawCoordinatSystem(camera->GetViewMatrix(), projectionMatrix);
}

void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, int collision,int is_person,int apply_light, Texture2D* texture)
{
	if (!mesh || !shader || !shader->program)
		return;

	glUseProgram(shader->program);
	
	
	// render an object using the specified shader and the specified position
	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = camera->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	glUniform1i(glGetUniformLocation(shader->program, "collision"), collision);
	glUniform1i(glGetUniformLocation(shader->program, "pers"), is_person);
	glUniform1i(glGetUniformLocation(shader->program, "superspeed"), super_speed);
	glUniform1i(glGetUniformLocation(shader->program, "death"), death);
	glUniform1f(glGetUniformLocation(shader->program, "time"), time_of_death);
	glUniform1i(glGetUniformLocation(shader->program, "apply_light"), apply_light);
	// Draw the object

	int light_position = glGetUniformLocation(shader->program, "light_position");
	glUniform3f(light_position, 0, 50 * cos(sun_rotation), 50 * sin(sun_rotation));
	glUniform3f(glGetUniformLocation(shader->program, "far"), pers.tx, pers.ty, pers.tz - 2 * masina.sz);

	int light_direction = glGetUniformLocation(shader->program, "light_direction");
	glUniform3f(light_direction, 0, -1, -1);

	int material_shininess = glGetUniformLocation(shader->program, "material_shininess");
	glUniform1i(material_shininess, materialShininess);

	int material_kd = glGetUniformLocation(shader->program, "material_kd");
	glUniform1f(material_kd, materialKd);

	int material_ks = glGetUniformLocation(shader->program, "material_ks");
	glUniform1f(material_ks, materialKs);


	int spot_location = glGetUniformLocation(shader->program, "is_spot");
	glUniform1i(spot_location, spot);

	int cut_location = glGetUniformLocation(shader->program, "cut_off_angle");
	glUniform1f(cut_location, cut_off_angle);

	if (texture)
	{
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture->GetTextureID());
		glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);
	}
	
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);

}

void Tema2::Render2DMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, Texture2D* texture)
{
	if (!mesh || !shader || !shader->program)
		return;

	glUseProgram(shader->program);


	// render an object using the specified shader and the specified position
	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	if (texture)
	{
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture->GetTextureID());
		glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);
	}

	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);

}

void Tema2::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->KeyHold(GLFW_KEY_W) && start) {
		if (speed < max_speed && super_speed == 0) {
			speed += deltaTime;
		}
	}
	if (window->KeyHold(GLFW_KEY_S) && start) {
		if (speed > min_speed && super_speed == 0)
			speed -= deltaTime;
	}
	if (window->KeyHold(GLFW_KEY_A) && start) {
		if(pers.tx > -6)
			pers.tx -= deltaTime * pers.speed;
	}
	if (window->KeyHold(GLFW_KEY_D) && start) {
		if(pers.tx < 6)
			pers.tx += deltaTime * pers.speed;
	}
}

void Tema2::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_C)
	{
		renderCameraTarget = !renderCameraTarget;
	}
	if (key == GLFW_KEY_P && death == 0)
	{
		start = !start;
	}
	if (key == GLFW_KEY_SPACE && fall && start)
	{
		pers.jump = true;
		gravity = max_gravity;
	}
	if (key == GLFW_KEY_R && !start)
	{
		restart();
	}
}

void Tema2::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema2::OnWindowResize(int width, int height)
{
}