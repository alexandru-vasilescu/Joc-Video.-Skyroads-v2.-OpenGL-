#include "Lane.h"

using namespace std;
using namespace Transform3D;

Lane::Lane()
{
}

Lane::Lane(float start_position, float tx)
{
	this->tx = tx;
	StartPlatforms(start_position);
}

Lane::~Lane()
{
}
double Lane::random_number(int start, int end)
{
	double x = (double)rand() / RAND_MAX;
	return start + (end - start) * x;
}
void Lane::StartPlatforms(float start_position)
{
	float z_center;
	z_center = start_position;
	while (z_center >= max_z)
	{
		platforma p;
		p.empty = center_empty;
		center_empty = !center_empty;
		if (p.empty)
			p.sz = random_number(2,4);
		else
			p.sz = random_number(10, 30);
		p.sx = random_number(2, 4);
		if(!p_center.empty())
			z_center -= p.sz / 2;
		p.tz = z_center;
		p.tx = this->tx;
		z_center -= p.sz/2;
		p_center.push_back(p);
		p.has_obstacle = false;
	}
	aux.empty = center_empty;
	center_empty = !center_empty;
	if (aux.empty)
		aux.sz = random_number(2, 4);
	else
		aux.sz = random_number(10, 30);
	aux.tz = max_z;
	aux.tx = this->tx;
	aux.has_obstacle = false;
}

void Lane::PlatformGenerator()
{
	platforma p = p_center[p_center.size() - 1];
	if (aux.tz <= p.tz - p.sz / 2 - aux.sz / 2)
	{
		p_center.push_back(aux);
		
		aux.empty = center_empty;
		center_empty = !center_empty;
		if (aux.empty)
			aux.sz = random_number(2, 5);
		else
			aux.sz = random_number(10, 20);
		aux.sx = random_number(2, 4);
		aux.coins.clear();
		aux.tz = max_z;
		aux.tx = this->tx;
		aux.has_fuel_canister = false;
		float chance = random_number(0, 100);

		if(chance < chance_of_obstacles)
		{
			aux.has_obstacle = true;
			aux.obstacle_type = (int)random_number(0, 4);
			aux.position_platform = random_number(-aux.sz / 2 + 1, aux.sz / 2 - 1);
			if(aux.obstacle_type == 0)
			{
				aux.o.tx = aux.tx;
				aux.o.tz = aux.tz + aux.position_platform;
				aux.o.sx = aux.sx;
				aux.o.sy = 1;
				aux.o.sz = 1;
			}
			if (aux.obstacle_type == 1)
			{
				aux.o.tx = aux.tx;
				aux.o.tz = aux.tz + aux.position_platform;
				aux.o.sx = aux.sx;
				aux.o.sy = 3;
				aux.o.sz = 0.3;
			}
			if (aux.obstacle_type == 2)
			{
				aux.o.tx = aux.tx;
				aux.o.tz = aux.tz + aux.position_platform;
				aux.o.sx = aux.sx;
				aux.o.sy = 0.5;
				aux.o.sz = 0.25;
			}
			if (aux.obstacle_type == 3)
			{
				aux.o.tx = aux.tx;
				aux.o.tz = aux.tz + aux.position_platform;
				aux.o.sx = 1;
				aux.o.sy = 1;
				aux.o.sz = 1;
			}
		}else
		{
			aux.has_obstacle = false;
			aux.obstacle_type = (int)random_number(5, 10);
			if (aux.obstacle_type == 5 || aux.obstacle_type == 6)
			{
				int number_coins = 10;
				for (int i = 0; i < number_coins; i++)
				{
					coin c;
					c.tz = aux.tz + aux.sz / (number_coins - 1) * i - aux.sz / 2;
					c.tx = aux.tx;
					aux.coins.push_back(c);
				}
			}
			if (aux.obstacle_type == 7) {
				aux.has_fuel_canister = true;
				aux.fuel_tank.tx = aux.tx;
				aux.fuel_tank.tz = aux.tz;
			}
		}
	}
}