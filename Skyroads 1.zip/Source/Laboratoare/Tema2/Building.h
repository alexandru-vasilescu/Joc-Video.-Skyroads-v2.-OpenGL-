#pragma once
#include <string>
#include <vector>
#include <iostream>
#include "Transform3D.h"
#include "Structures.h"

class Building
{
public:
	std::vector<cladire> cladiri;
	Building();
	Building(float start, float tx);
	~Building();

	void PlatformGenerator();
	double random_number(int start, int end);
	void StartPlatforms(float start);

private:
	float max_z = -30;
	float tx;
	cladire aux;
};