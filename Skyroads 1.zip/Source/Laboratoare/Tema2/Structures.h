#pragma once

struct obstacol
{
	float tx, tz;
	float sx, sy, sz;
	bool draw = true;
};

struct coin
{
	float tx, ty = 0.5, tz;
	float sx = 0.2, sy = 0.2, sz = 0.2;
	float rotation = 0;
	float up = 0;
	int sign = -1;
	bool draw = true;
};
struct fuel_tank
{
	float tx, ty = 0.5, tz;
	float sx = 0.5, sy = 0.5, sz = 0.5;
	float rotation = 0;
	float up = 0;
	int sign = -1;
	bool draw = true;
};
struct platforma
{
	float tx, tz;
	float sx = 3, sy = 0.2, sz = 4;
	bool empty;
	bool has_obstacle;
	int obstacle_type;
	float position_platform;
	obstacol o;
	std::vector<coin> coins;
	bool has_fuel_canister;
	fuel_tank fuel_tank;
};

struct personaj
{
	float tx, tz, ty;
	float sx = 0.5, sy = 0.5, sz = 0.5;
	float speed = 2;
	bool jump = false;
	int lives = 1;
};

struct masina
{
	float tx, tz, ty;
	float sx = 0.5, sy = 0.5, sz = 0.5;
};

struct cladire
{
	float tx, ty, tz;
	float sx = 2, sy = 2, sz = 2;
	int floors;
	std::vector<int> texture_type;
};