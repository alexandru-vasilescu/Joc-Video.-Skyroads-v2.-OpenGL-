#include "Building.h"

using namespace std;
using namespace Transform3D;

Building::Building()
{
	
}


Building::Building(float start_position, float tx)
{
	this->tx = tx;
	StartPlatforms(start_position);
}

Building::~Building()
{
}
double Building::random_number(int start, int end)
{
	double x = (double)rand() / RAND_MAX;
	return start + (end - start) * x;
}
void Building::StartPlatforms(float start_position)
{
	float z_center;
	z_center = start_position;
	while (z_center >= max_z)
	{
		cladire c;
		c.ty = 0;
		c.tz = z_center;
		c.tx = this->tx;
		z_center -= 2;
		c.floors = (int)random_number(1, 10);
		for(int i = 0 ; i < c.floors; i++)
		{
			int j = (int)random_number(0, 2);
			c.texture_type.push_back(j);
		}
		cladiri.push_back(c);
	}
	
	aux.tz = max_z;
	aux.tx = this->tx;
	aux.ty = 0;
	aux.floors = (int)random_number(1, 10);
	for (int i = 0; i < aux.floors; i++)
	{
		int j = (int)random_number(0, 2);
		aux.texture_type.push_back(j);
	}
}

void Building::PlatformGenerator()
{
	if(cladiri[cladiri.size() - 1].tz > max_z + 2)
	{
		cladiri.push_back(aux);
		aux.texture_type.clear();
		aux.tz = max_z;
		aux.tx = this->tx;
		aux.ty = 0;
		aux.floors = (int)random_number(0, 5);
		for (int i = 0; i < aux.floors; i++)
		{
			int j = (int)random_number(0, 3);
			aux.texture_type.push_back(j);
		}
	}
	// platforma p = p_center[p_center.size() - 1];
	// if (aux.tz <= p.tz - p.sz / 2 - aux.sz / 2)
	// {
	// 	p_center.push_back(aux);
	//
	// 	aux.empty = center_empty;
	// 	center_empty = !center_empty;
	// 	if (aux.empty)
	// 		aux.sz = random_number(2, 5);
	// 	else
	// 		aux.sz = random_number(10, 20);
	// 	aux.sx = random_number(2, 4);
	// 	aux.coins.clear();
	// 	aux.tz = max_z;
	// 	aux.tx = this->tx;
	// 	aux.has_fuel_canister = false;
	// 	float chance = random_number(0, 100);
	//
	// 	if (chance < chance_of_obstacles)
	// 	{
	// 		aux.has_obstacle = true;
	// 		aux.obstacle_type = (int)random_number(0, 4);
	// 		aux.position_platform = random_number(-aux.sz / 2 + 1, aux.sz / 2 - 1);
	// 		if (aux.obstacle_type == 0)
	// 		{
	// 			aux.o.tx = aux.tx;
	// 			aux.o.tz = aux.tz + aux.position_platform;
	// 			aux.o.sx = aux.sx;
	// 			aux.o.sy = 1;
	// 			aux.o.sz = 1;
	// 		}
	// 		if (aux.obstacle_type == 1)
	// 		{
	// 			aux.o.tx = aux.tx;
	// 			aux.o.tz = aux.tz + aux.position_platform;
	// 			aux.o.sx = aux.sx;
	// 			aux.o.sy = 3;
	// 			aux.o.sz = 0.3;
	// 		}
	// 		if (aux.obstacle_type == 2)
	// 		{
	// 			aux.o.tx = aux.tx;
	// 			aux.o.tz = aux.tz + aux.position_platform;
	// 			aux.o.sx = aux.sx;
	// 			aux.o.sy = 0.5;
	// 			aux.o.sz = 0.25;
	// 		}
	// 		if (aux.obstacle_type == 3)
	// 		{
	// 			aux.o.tx = aux.tx;
	// 			aux.o.tz = aux.tz + aux.position_platform;
	// 			aux.o.sx = 1;
	// 			aux.o.sy = 1;
	// 			aux.o.sz = 1;
	// 		}
	// 	}
	// 	else
	// 	{
	// 		aux.has_obstacle = false;
	// 		aux.obstacle_type = (int)random_number(5, 10);
	// 		if (aux.obstacle_type == 5 || aux.obstacle_type == 6)
	// 		{
	// 			int number_coins = 10;
	// 			for (int i = 0; i < number_coins; i++)
	// 			{
	// 				coin c;
	// 				c.tz = aux.tz + aux.sz / (number_coins - 1) * i - aux.sz / 2;
	// 				c.tx = aux.tx;
	// 				aux.coins.push_back(c);
	// 			}
	// 		}
	// 		if (aux.obstacle_type == 7) {
	// 			aux.has_fuel_canister = true;
	// 			aux.fuel_tank.tx = aux.tx;
	// 			aux.fuel_tank.tz = aux.tz;
	// 		}
	// 	}
	// }
}